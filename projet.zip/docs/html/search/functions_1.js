var searchData=
[
  ['construire_5fquadtree_31',['construire_quadtree',['../quadtree_8c.html#a6e2835886e6ade22ece4feafbb6d9618',1,'construire_quadtree(unsigned char *pixels, int largeur, int hauteur, int x, int y, int taille):&#160;quadtree.c'],['../quadtree_8h.html#a6e2835886e6ade22ece4feafbb6d9618',1,'construire_quadtree(unsigned char *pixels, int largeur, int hauteur, int x, int y, int taille):&#160;quadtree.c']]]
];
