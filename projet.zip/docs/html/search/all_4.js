var searchData=
[
  ['lire_5ffichier_7',['lire_fichier',['../traitementPGM_8c.html#a2691cb32970d4c6367900f5ce397d872',1,'lire_fichier(const char *filename, int *nbc, int *nbl, int *nbg, unsigned char **pixmap):&#160;traitementPGM.c'],['../traitementPGM_8h.html#a2691cb32970d4c6367900f5ce397d872',1,'lire_fichier(const char *filename, int *nbc, int *nbl, int *nbg, unsigned char **pixmap):&#160;traitementPGM.c']]]
];
