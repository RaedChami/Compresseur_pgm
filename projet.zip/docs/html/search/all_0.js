var searchData=
[
  ['afficher_5fpremiers_5fpixels_0',['afficher_premiers_pixels',['../traitementPGM_8c.html#ab4756b3aebd4d398cd1b120cf308dc15',1,'afficher_premiers_pixels(unsigned char *pixmap, int nbc, int nbl):&#160;traitementPGM.c'],['../traitementPGM_8h.html#ab4756b3aebd4d398cd1b120cf308dc15',1,'afficher_premiers_pixels(unsigned char *pixmap, int nbc, int nbl):&#160;traitementPGM.c']]],
  ['afficher_5fquadtree_1',['afficher_quadtree',['../quadtree_8c.html#a6c7fd49121c3f13039dd777777bb02cd',1,'afficher_quadtree(Noeud *noeud, int niveau):&#160;quadtree.c'],['../quadtree_8h.html#a6c7fd49121c3f13039dd777777bb02cd',1,'afficher_quadtree(Noeud *noeud, int niveau):&#160;quadtree.c']]],
  ['alloue_5fnoeud_2',['alloue_noeud',['../quadtree_8c.html#abc493c42e45d82018bfe3273e27b1b38',1,'alloue_noeud(unsigned char valeur, unsigned char erreur, bool uniforme):&#160;quadtree.c'],['../quadtree_8h.html#abc493c42e45d82018bfe3273e27b1b38',1,'alloue_noeud(unsigned char valeur, unsigned char erreur, bool uniforme):&#160;quadtree.c']]]
];
