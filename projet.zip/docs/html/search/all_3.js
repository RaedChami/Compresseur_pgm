var searchData=
[
  ['getdimensions_5',['getDimensions',['../traitementPGM_8c.html#a1e2756ef8ace42e12e20bf2a22c76de7',1,'getDimensions(int nbc, int nbl):&#160;traitementPGM.c'],['../traitementPGM_8h.html#a1e2756ef8ace42e12e20bf2a22c76de7',1,'getDimensions(int nbc, int nbl):&#160;traitementPGM.c']]],
  ['getgraylevel_6',['getGrayLevel',['../traitementPGM_8c.html#a78c2f677370604f6f167bb29538d2ac9',1,'getGrayLevel(int nbg):&#160;traitementPGM.c'],['../traitementPGM_8h.html#a78c2f677370604f6f167bb29538d2ac9',1,'getGrayLevel(int nbg):&#160;traitementPGM.c']]]
];
