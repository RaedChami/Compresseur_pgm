var searchData=
[
  ['construit_5fpixmap_3',['construit_pixmap',['../traitementPGM_8c.html#a6112469c9e16b44178b5b85a50dabf7f',1,'construit_pixmap(int nbc, int nbl):&#160;traitementPGM.c'],['../traitementPGM_8h.html#a6112469c9e16b44178b5b85a50dabf7f',1,'construit_pixmap(int nbc, int nbl):&#160;traitementPGM.c']]]
];
