Pour la phase 1, notre projet ne dépends d'aucune librairies externe.
Le répertoire est donc pour l'instant vide.