package graphical.main;

import java.awt.Color;
import com.github.forax.zen.Application;
import graphical.ui.MenuEventManager;

public class Main {
	public static void main(String[] args) {
		Application.run(Color.WHITE, context -> {
			MenuEventManager menuController = new MenuEventManager(context);
			menuController.run();
		});
	}
}