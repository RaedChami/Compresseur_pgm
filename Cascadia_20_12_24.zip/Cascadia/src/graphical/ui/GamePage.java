package graphical.ui;

public enum GamePage {
	PLAY_GAME, OPTIONS, QUIT_GAME, MAIN_MENU
}
