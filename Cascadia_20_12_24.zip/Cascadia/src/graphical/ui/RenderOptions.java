package graphical.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Objects;

public class RenderOptions {
	private BufferedImage panel;
	private int width;
	private int height;

	public RenderOptions(BufferedImage panel, int width, int height) {
		this.panel = Objects.requireNonNull(panel);
		this.width = width;
		this.height = height;
	}

	public void render(Graphics2D graphics) {
		graphics.setColor(Color.YELLOW);
		graphics.fillRect(0, 0, width, height);

		graphics.drawImage(panel, 0, 0, width, height, null);
		graphics.setColor(Color.WHITE);
		graphics.setFont(new Font("Arial", Font.BOLD, 100));

		String optionsText = "OPTION TEST";
		int textWidth = graphics.getFontMetrics().stringWidth(optionsText);
		graphics.drawString(optionsText, width / 2 - textWidth / 2, height / 2);
	}

}
