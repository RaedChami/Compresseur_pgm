package graphical.ui;

import com.github.forax.zen.ApplicationContext;
import com.github.forax.zen.KeyboardEvent;
import com.github.forax.zen.PointerEvent;

import graphical.resources.ResourceLoader;

import java.awt.image.BufferedImage;

public class MenuEventManager {
	private ApplicationContext context;
	private ResourceLoader resourceLoader;
	private BufferedImage background;
	private BufferedImage button;
	private BufferedImage panel;
	private int width;
	private int height;

	private GamePage currentScene = GamePage.MAIN_MENU;

	public MenuEventManager(ApplicationContext context) {
		this.context = context;
		initializeResources();
	}

	private void initializeResources() {
		resourceLoader = new ResourceLoader();
		String[] imageNames = { "menu.jpg", "button.png" , "optionPanel2.jpg" };
		resourceLoader.loadImages(imageNames);

		background = resourceLoader.getBackgroundImage();
		button = resourceLoader.getButtonImage();
		panel = resourceLoader.getPanel();
		var screenInfo = context.getScreenInfo();
		width = screenInfo.width();
		height = screenInfo.height();
	}

	public void run() {
		while (true) {
			switch (currentScene) {
			case PLAY_GAME -> renderGame();
			case MAIN_MENU -> renderMainMenu();
			case OPTIONS -> renderOptionsMenu();
			case QUIT_GAME -> context.dispose();
			default -> throw new IllegalArgumentException();
			}
		}
	}

	private void renderMainMenu() {
		RenderMenu menuRenderer = new RenderMenu(background, button, width, height);
		
		if (background == null || button == null) {
			System.err.println("Resource error");
			return;
		}
		context.renderFrame(graphics -> {
			menuRenderer.render(graphics);
		});

		manageMainMenuEvents();
	}

	private void renderOptionsMenu() {
		RenderOptions optionRenderer = new RenderOptions(panel, width, height);
		context.renderFrame(graphics -> {
			optionRenderer.render(graphics);
		});

		detectBackToMenu();
	}

	private void renderGame() {
		RenderGame gameRenderer = new RenderGame(width, height);
		context.renderFrame(graphics -> {
			gameRenderer.render(graphics);
		});

		detectBackToMenu();
	}	

	/**
	 * Manages main menu events.
	 */
	private void manageMainMenuEvents() {
		var event = context.pollOrWaitEvent(10);
		if (event == null)
			return;
		switch (event) {
			case PointerEvent e -> {
	      if (e.action() == PointerEvent.Action.POINTER_UP) {	
	        int x = e.location().x();
	        int y = e.location().y();
	        detectPageSwitching(x, y);
	      }			
			}
	    case KeyboardEvent e -> { 
	      switch (e.action()) {
	      case KEY_RELEASED, KEY_PRESSED -> {}  // Ignore key events
	      }    	
	    }		
		default -> throw new IllegalArgumentException();
		}
	}

	/**
	 * Detects page switching from Menu.
	 * @param clickX X coordinate of mouse click
	 * @param clickY Y coordinate of mouse click
	 */
	private void detectPageSwitching(int clickX, int clickY) {
		int buttonX = width / 3;
		int buttonWidth = 700;
		int buttonHeight = 350;
		int startButtonY = height / 3 + 150;
		int optionButtonY = height / 3 + 265;
		int quitButtonY = height / 3 + 380;

		if (isButtonClicked(clickX, clickY, buttonX, quitButtonY, buttonWidth, buttonHeight)) {
			currentScene = GamePage.QUIT_GAME; // Quit game
		} else if (isButtonClicked(clickX, clickY, buttonX, optionButtonY, buttonWidth, buttonHeight)) {
			currentScene = GamePage.OPTIONS; // Switch to options scene
		} else if (isButtonClicked(clickX, clickY, buttonX, startButtonY, buttonWidth, buttonHeight)) {
			currentScene = GamePage.PLAY_GAME; // Switch to game scene
		}
	}
	
	/**
	 * Detects back to menu click.
	 */
	private void detectBackToMenu() {
		var event = context.pollOrWaitEvent(10);
		if (event == null)
			return;

		switch (event) {
			case PointerEvent e -> {
				currentScene = GamePage.MAIN_MENU;
			}
	    case KeyboardEvent e -> {
	      switch (e.action()) {
	      case KEY_RELEASED, KEY_PRESSED -> {} // Ignore key events
	      }    	
	    }
		default -> throw new IllegalArgumentException();  
		}
	}

	/**
	 * Checks if button is clicked.
	 * @param clickX X coordinate of mouse click
	 * @param clickY Y coordinate of mouse click
	 * @param buttonX X coordinate of button
	 * @param buttonY Y coordinate of button
	 * @param buttonWidth Width of button
	 * @param buttonHeight Height of button
	 * @return
	 */
	private boolean isButtonClicked(int clickX, int clickY, int buttonX, int buttonY, int buttonWidth, int buttonHeight) {
		return (clickX >= buttonX + 170 && clickX <= buttonX + buttonWidth - 170)
				&& (clickY >= buttonY + 120 && clickY <= buttonY + buttonHeight - 120);
	}
}