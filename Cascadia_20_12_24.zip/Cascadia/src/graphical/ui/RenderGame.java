package graphical.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class RenderGame {
	private int width;
	private int height;

	public RenderGame(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public void render(Graphics2D graphics) {
		graphics.setColor(Color.YELLOW);
		graphics.fillRect(0, 0, width, height);

		graphics.setColor(Color.WHITE);
		graphics.setFont(new Font("Arial", Font.BOLD, 100));

		String optionsText = "GAME TEST";
		int textWidth = graphics.getFontMetrics().stringWidth(optionsText);
		graphics.drawString(optionsText, width / 2 - textWidth / 2, height / 2);
	}

}