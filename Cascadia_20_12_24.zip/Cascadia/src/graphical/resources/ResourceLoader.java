package graphical.resources;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

public class ResourceLoader {
	private BufferedImage backgroundImage;
	private BufferedImage buttonImage;
	private BufferedImage panel;
	/**
	 * Loads images into the game's images data.
	 * 
	 * @param imageNames List of images to be loaded
	 * @return List of buffered images
	 */
	public List<BufferedImage> loadImages(String[] imageNames) {
		List<BufferedImage> images = new ArrayList<>();

		for (var imageName : imageNames) {
			try (InputStream input = ResourceLoader.class.getResourceAsStream("/images/" + imageName)) {
				if (input == null) {
					System.err.println("Error! Image not found");
				}
				var image = ImageIO.read(input);
				images.add(image);
				if (imageName.equals("menu.jpg"))
					backgroundImage = image; // Sets the BG image to the appropriate variable
				else if (imageName.equals("button.png"))
					buttonImage = image; // Sets the button image to the appropriate variable
				else if (imageName.equals("optionPanel2.jpg"))
					panel = image;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return images;
	}

	public BufferedImage getBackgroundImage() {
		return backgroundImage;
	}

	public BufferedImage getButtonImage() {
		return buttonImage;
	}

	public BufferedImage getPanel() {
		return panel;
	}
}