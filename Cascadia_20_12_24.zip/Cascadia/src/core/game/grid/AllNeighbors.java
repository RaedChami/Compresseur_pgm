package core.game.grid;

public class AllNeighbors implements NeighborStrategy {
	@Override
	public int[][] getNeighbors() {
		return new int[][] { { -1, -1 }, { -1, 0 }, { -1, 1 }, // Haut gauche, Haut, Haut droite
				{ 0, -1 }, { 0, 1 }, // Gauche, Droite
				{ 1, -1 }, { 1, 0 }, { 1, 1 } // Bas gauche, Bas, Bas droite
		};
	}
}
