package core.game;

import core.game.grid.*;
import core.game.player.*;
import terminal.ui.GameUI;
import core.game.mechanics.*;
import java.util.List;
import java.util.Objects;

/**
 * Defines the game logic of Cascadia.
 */
public class Game {
	private final Grid grid1;
	private final Grid grid2;
	private final Player player1;
	private final Player player2;
	private final PositionInput input;
	private final Deck deck;
	private final VariantScoring scoring;
	private final GameVariant variant;
	private final GameUI gameUI;

	/**
	 * Constructs a new game instance.
	 */
	public Game() {
		this.deck = new Deck();
		this.variant = new GameVariant();
		this.scoring = new VariantScoring(this.variant);
		this.gameUI = new GameUI();
		player1 = new Player("Joueur 1", scoring);
		player2 = new Player("Joueur 2", scoring);
		grid1 = new Grid(5, deck, player1); // Exemple avec une grille 5x5
		grid2 = new Grid(5, deck, player2);
		input = new PositionInput(0, 0);
	}

	/**
	 * Removes null tiles from tiles list and draws a new tile from the deck if
	 * available.
	 * 
	 * @param tiles List of tiles
	 */
	public void removeTiles(List<Tile> tiles) {
		tiles.removeIf(t -> t == null); // on retire la tuile qu'on a marqué null car jouée
		if (!deck.getTiles().isEmpty()) {
			tiles.add(deck.drawTiles(1).get(0));
		}
	}

	/**
	 * Core method of Cascadia that manages the steps from the start to the end of a
	 * game.
	 */
	public void startGame() {
		int roundCount = 1;
		int NumberOfTurns = 2;
		gameUI.displayStartMenu();
		variant.variantChoice(); // Choice of variant
		boolean redrawFor3 = gameUI.askForRedrawPreference(); // Choice of redraw preference

		// Tirage initial de tuiles pour Joueur 1
		List<Tile> pickedTiles = drawValidTiles(grid1, deck, redrawFor3);

		// Boucle principale du jeu
		while (roundCount < NumberOfTurns + 1 && !deck.getTiles().isEmpty()) {
			System.out.println("------Tour " + roundCount + "------");

			// Tour du joueur 1
			if ((!areTilesPlayable(grid1, pickedTiles) || Tile.getMaxCombinationCount(pickedTiles) == 4
					|| (Tile.getMaxCombinationCount(pickedTiles) == 3 && redrawFor3))) {
				pickedTiles = drawValidTiles(grid1, deck, redrawFor3);
			}
			executePlayerTurn("Joueur 1", player1, grid1, pickedTiles);

			// Tour du joueur 2
			if (!deck.getTiles().isEmpty()) {
				if ((!areTilesPlayable(grid2, pickedTiles) || Tile.getMaxCombinationCount(pickedTiles) == 4
						|| (Tile.getMaxCombinationCount(pickedTiles) == 3 && redrawFor3))) {
					pickedTiles = drawValidTiles(grid2, deck, redrawFor3);
				}
				executePlayerTurn("Joueur 2", player2, grid2, pickedTiles);
			}
			roundCount++;
		}
		gameUI.endGame(grid1, grid2, player1, player2);
	}

	// Draws valid tiles according to the state of the game.
	private List<Tile> drawValidTiles(Grid grid, Deck deck, boolean redrawFor3) {
		List<Tile> pickedTiles;
		do {
			pickedTiles = deck.drawTiles(4);
		} while (!areTilesPlayable(grid, pickedTiles) || Tile.getMaxCombinationCount(pickedTiles) == 4
				|| (Tile.getMaxCombinationCount(pickedTiles) == 3 && redrawFor3));
		return pickedTiles;
	}

	// Checks if at least one of the proposed tiles are placeable on the grid.
	private boolean areTilesPlayable(Grid grid, List<Tile> tiles) {
		for (Tile tile : tiles) {
			if (tile != null && Tile.isTilePlayable(grid, tile)) {
				return true;
			}
		}
		return false;
	}

	// Manages a complete round of a player.
	private void executePlayerTurn(String playerName, Player player, Grid grid, List<Tile> pickedTiles) {
		System.out.println(playerName + " :");
		gameUI.displayTileChoices(pickedTiles);
		player_Round(player, grid, pickedTiles);
		removeTiles(pickedTiles);
	}

	/**
	 * Manages the UI round of a player
	 * 
	 * @param player         Player of the round
	 * @param grid           In-game grid of player
	 * @param availableTiles List of available tiles proposed to the player
	 */
	public void player_Round(Player player, Grid grid, List<Tile> availableTiles) {
		Objects.requireNonNull(player, "player cannot be null");
		Objects.requireNonNull(grid, "grid cannot be null");
		Objects.requireNonNull(availableTiles, "availableTiles cannot be null");
		grid.displayGrid();
		// Choix de la tuile par le joueur
		System.out.println("Sélectionnez une tuile (1-" + availableTiles.size() + ") :");
		Tile chosenTile = Tile.chooseTile(grid, availableTiles);
		Wildlife animal = chosenTile.getWildlife().get(0);
		do {
			System.out.println(player.getName() + ", où voulez-vous placer la tuile " + chosenTile.getHabitat() + " ?");
			input.readPositions(grid);
		} while (!player.placeTile(chosenTile, grid, input.getY(), input.getX())); // Les coordonnées sont inversées avec
																																								// l'affichage

		grid.displayGrid(); // pour voir si la tuile qu'on vient de placer accepte notre animal

		// Placement des animaux de la tuile
		do {
			System.out.println(player.getName() + ", où voulez-vous placer l'animal " + animal + " ?");
			input.readPositions(grid);
		} while (!player.placeWildlife(grid, input.getY(), input.getX(), animal)); // Les coordonnées sont inversées avec
																																								// l'affichage
	}

}
