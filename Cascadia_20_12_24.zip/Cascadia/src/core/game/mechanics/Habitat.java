package core.game.mechanics;

/**
 * Habitat tiles
 */
public enum Habitat {
	Fleuve, Marais, Forêt, Prairie, Montagne;
}