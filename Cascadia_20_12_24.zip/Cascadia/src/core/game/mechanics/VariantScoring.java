package core.game.mechanics;

import core.game.GameVariant;
import core.game.player.*;
import core.game.grid.*;
import java.io.IO;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Represents the variant's scoring system in Cascadia, implements the
 * GameVariant interface that defines how points are calculated based on the
 * game variant (special variants or standard variant).
 */
public class VariantScoring implements PlayerScore {
	private final GameVariant variant;

	/**
	 * Constructor of VariantScoring class.
	 * 
	 * @param variant Variant of game
	 */
	public VariantScoring(GameVariant variant) {
		this.variant = Objects.requireNonNull(variant, "Variant cannot be null");
	}

	@Override
	public int wildlifeScoring(Grid grid) { // Calcule et affiche le score des jetons faune
		Objects.requireNonNull(grid, "grid cannot be null");
		var finalWildlives = grid.countWildlifeInGrid(grid);
		int wildlivesTotal = 0;
		int keyWidth = 7;
		IO.println("* Points jetons faune : " + grid.getPlayerOnGrid());
		for (var wildlife : finalWildlives.entrySet()) {
			int wildlifeTotal = 0;
			for (var number : wildlife.getValue()) {
				wildlifeTotal += calculateWildlifePoints(variant, number); // Les points accordés au joueur dépendent de la
																																		// taille du groupe
				wildlivesTotal += wildlifeTotal;
			}
			IO.println(String.format("%-" + keyWidth + "s", wildlife.getKey()) + " : " + wildlifeTotal);
		}
		return wildlivesTotal;
	}

	@Override
	public int habitatScoring(Grid grid) { // Calcule et affiche le score des habitats
		Objects.requireNonNull(grid, "grid cannot be null");
		var finalHabitats = getMaxSizeHabitat(grid);
		int habitatTotal = 0;
		IO.println("* Points habitats : " + grid.getPlayerOnGrid());
		for (var habitat : finalHabitats.entrySet()) {
			IO.println(habitat.getKey() + " : " + habitat.getValue());
			habitatTotal += habitat.getValue();
		}
		System.out.println();
		return habitatTotal;
	}

	/**
	 * Returns a map containing each habitat used in game as keys, and the largest
	 * group size of the habitat as values.
	 * 
	 * @param grid In-game grid
	 * @return Map containing habitats and their largest group size as values
	 */
	public Map<Habitat, Integer> getMaxSizeHabitat(Grid grid) {
		Objects.requireNonNull(grid, "grid cannot be null");
		Map<Habitat, List<Integer>> habitatPoints = grid.countHabitatInGrid(grid);
		return habitatPoints.entrySet().stream().collect(
				Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().stream().max(Integer::compareTo).orElse(0)));
	}

	@Override
	public Map<String, Integer> majorityBonusPoints(Grid grid1, Grid grid2) {
		Objects.requireNonNull(grid1, "grid1 cannot be null");
		Objects.requireNonNull(grid2, "grid2 cannot be null");
		Map<String, Integer> bonusPerPlayer = new HashMap<>();
		Set<Habitat> allHabitats = new HashSet<>(); // Tout types d'habitats utilisés par les joueurs
		var p1HabitatScores = getMaxSizeHabitat(grid1);
		var p2HabitatScores = getMaxSizeHabitat(grid2);
		allHabitats.addAll(p1HabitatScores.keySet());
		allHabitats.addAll(p2HabitatScores.keySet());
		bonusPerPlayer.put(grid1.getPlayerOnGrid(), 0);
		bonusPerPlayer.put(grid2.getPlayerOnGrid(), 0);
		for (var habitat : allHabitats) {
			int p1Score = p1HabitatScores.getOrDefault(habitat, 0);
			int p2Score = p2HabitatScores.getOrDefault(habitat, 0);
			compareHabitatScores(p1Score, p2Score, bonusPerPlayer, grid1, grid2);
		}
		return bonusPerPlayer;
	}

	/**
	 * Compares the habitat scores of players in order to attribute the bonus
	 * points.
	 * 
	 * @param p1Score  habitat score of first player
	 * @param p2Score  habitat score of second player
	 * @param bonusMap Map to fill with bonus points
	 * @param grid1    In-game grid of first player
	 * @param grid2    In-game grid of second player
	 */
	public void compareHabitatScores(int p1Score, int p2Score, Map<String, Integer> bonusMap, Grid grid1, Grid grid2) {
		Objects.requireNonNull(bonusMap, "bonusMap cannot be null");
		Objects.requireNonNull(grid1, "grid1 cannot be null");
		Objects.requireNonNull(grid2, "grid2 cannot be null");
		if (p1Score > p2Score) {
			bonusMap.put(grid1.getPlayerOnGrid(), bonusMap.get(grid1.getPlayerOnGrid()) + 2);
		} else if (p2Score > p1Score)
			bonusMap.put(grid2.getPlayerOnGrid(), bonusMap.get(grid2.getPlayerOnGrid()) + 2);
		else {
			bonusMap.put(grid1.getPlayerOnGrid(), bonusMap.get(grid1.getPlayerOnGrid()) + 1);
			bonusMap.put(grid2.getPlayerOnGrid(), bonusMap.get(grid2.getPlayerOnGrid()) + 1);
		}
	}

	/**
	 * Determines the wildlife points of a player based on the variant.
	 * 
	 * @param variant In-game variant
	 * @param number  Size of wildlife group
	 * @return Wildlife point
	 */
	public int calculateWildlifePoints(GameVariant variant, int number) {
		Objects.requireNonNull(variant, "variant cannot be null");
		if (variant.getVariant() == 1) {
			return switch (number) { // Les points accordés au joueur dépendent de la taille du groupe
			case 1 -> 2;
			case 2 -> 5;
			default -> 9;
			};
		} else if (variant.getVariant() == 2) {
			return switch (number) {
			case 1 -> 0;
			case 2 -> 5;
			case 3 -> 8;
			default -> 12;
			};
		}
		return 0;
	}

}