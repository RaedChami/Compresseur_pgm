package core.game.mechanics;

/**
 * Wildlife tokens
 */
public enum Wildlife {
	Ours, Wapiti, Renard, Saumon, Buse;
}
