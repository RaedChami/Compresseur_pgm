package terminal.main;

import core.game.*;

/**
 * Main of Cascadia project.
 */
public class Main {
	/**
	 * Main method of Cascadia.
	 * 
	 * @param args Not used
	 */
	public static void main(String[] args) {
		Game game = new Game();
		game.startGame();
	}
}
