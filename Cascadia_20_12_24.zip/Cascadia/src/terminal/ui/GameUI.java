package terminal.ui;

import java.io.IO;
import java.util.List;
import java.util.Objects;

import core.game.grid.Grid;
import core.game.grid.Tile;
import core.game.player.Player;

/**
 * Manages User interface.
 */
public class GameUI {
	/**
	 * Displays title of the game.
	 */
	public void displayStartMenu() {
		IO.println("\u001B[32m**************");
		IO.println("*  CASCADIA  *");
		IO.println("**************\u001B[0m\n");
		IO.println("Bienvenue à Cascadia!\nQuelle variante du jeu souhaitez vous jouer?");
		IO.println("1. Variante familiale");
		IO.println("2. Variante intermédiaire");
		IO.println("3. Version normale");
	}

	/**
	 * Displays the proposed/available tiles to the player.
	 * 
	 * @param tiles List of available tiles
	 */
	public void displayTileChoices(List<Tile> tiles) {
		Objects.requireNonNull(tiles, "tiles cannot be null");
		System.out.println("Tuiles disponibles :");
		for (int i = 0; i < tiles.size(); i++) { // Affiche les tuiles
			Tile tile = tiles.get(i);
			System.out.println((i + 1) + ". " + tile.toString());
		}
	}

	/**
	 * Asks a player if he wants to redraw tiles if 3 proposed wildlife tokens are
	 * identical.
	 * 
	 * @return boolean
	 */
	public boolean askForRedrawPreference() {
		System.out.println("Voulez-vous repiocher si 3 jetons animaux sont identiques ? (o/n)");
		return "o".equalsIgnoreCase(IO.readln(""));
	}

	/**
	 * Manages the end of game UI (Various displays and score calculations)
	 */
	public void endGame(Grid grid1, Grid grid2, Player player1, Player player2) {
		int caseWidth = 2;
		System.out.println("\u001B[32m--------------Fin de jeu--------------------\u001B[0m");
		grid1.displayGrid();
		grid2.displayGrid();
		player1.calculateScores(grid1, grid2);
		player2.calculateScores(grid2, grid1);
		System.out.println();
		System.out.println("________SCORE________| " + player1.getName() + " | " + player2.getName());
		System.out
				.println(" Total jetons faune  |  " + player1.getWildlifeScore() + "       | " + player2.getWildlifeScore());
		System.out
				.println(" Total habitat       |  " + player1.getHabitatScore() + "       | " + player2.getHabitatScore());
		System.out.println(" Total bonus         |  " + player1.getBonusPoints() + "       | " + player2.getBonusPoints());
		System.out.println(" Score total         |  " + String.format("%-" + caseWidth + "s", player1.getTotalScore())
				+ "      | " + player2.getTotalScore());
		System.out.println();
		System.out.println(
				(player1.getTotalScore() > player2.getTotalScore() ? player1.getName() + " est le vainqueur de la partie\n"
						: (player1.getTotalScore() < player2.getTotalScore()
								? player2.getName() + " est le vainqueur de la partie\n"
								: "La partie est un match nul\n")));
	}

}
